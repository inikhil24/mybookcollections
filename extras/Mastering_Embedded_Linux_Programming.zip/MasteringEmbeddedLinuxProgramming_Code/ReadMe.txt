The software used in this book is entirely open source. The versions used are, in 
most cases, the latest stable versions available at the time of writing. While I have 
tried to describe the main features in a manner that are not specific to a particular 
version, it is inevitable that the examples of commands contain some details that 
will not work with the later versions. I hope that the descriptions that accompany 
them are sufficiently informative so that you can apply the same principles to the 
later versions of the package