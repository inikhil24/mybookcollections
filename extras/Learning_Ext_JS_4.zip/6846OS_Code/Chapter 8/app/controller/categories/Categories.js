/**
 * @class MyApp.controller.categories.Categories
 * @extends Ext.app.Controller
 * @author Crysfel Villa <crysfel@bleext.com>
 *
 * Description
 */

Ext.define('MyApp.controller.categories.Categories',{
	extend      : 'Ext.app.Controller',

	init   : function(){
		var me = this;


	}
});