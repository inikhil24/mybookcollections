/**
 * @class MyApp.controller.invoices.Invoices
 * @extends Ext.app.Controller
 * @author Crysfel Villa <crysfel@bleext.com>
 *
 * Description
 */

Ext.define('MyApp.controller.invoices.Invoices',{
	extend      : 'Ext.app.Controller',

	init   : function(){
		var me = this;


	}
});