Code files are present only for chapter 3, 5, and 9. These code files consists of projects which the reader have to import into the Android IDE.


Chapter 3
—————————
The project includes a main activity named “MainActivity” contained in the folder /src/main/java/com/example/myapplication/app.
The main activity includes the methods explained in Chapter 3, which are invoked when pressing the buttons from the main layout:
- startNewThread
- startMethodHierarchy
- memoryConsumption
- startNetworkConnection


Chapter 5
—————————
The project includes a main activity named “MainActivity” contained in the folder /src/main/java/com/example/myapplication2/app.
The main activity includes the three examples explained in Chapter 5, which are invoked in its onCreate method:
- createSharedPreferences
- encryptData
- encryptFile


Chapter 9
—————————
The project includes the main java classes under test contained in the folder /src/main/. The project also includes the test classes explained in Chapter 9, contained in the folder /src/androidTest/:
- MyActivityTest.java
- MyActivityUnitTest.java



