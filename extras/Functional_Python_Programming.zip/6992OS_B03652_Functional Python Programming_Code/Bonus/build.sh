python3 -m pylit chi_sq.py
rst2html.py --input-encoding=utf-8 chi_sq.py.txt chi_sq.py.html
python3 -m pylit case_study.py
rst2html.py --input-encoding=utf-8 case_study.py.txt case_study.py.html
