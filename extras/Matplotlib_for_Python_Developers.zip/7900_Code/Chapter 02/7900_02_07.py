#!/usr/bin/python

import matplotlib.pyplot as plt
plt.plot([1, 3, 2, 4])
plt.xlabel('This is the X axis')
plt.ylabel('This is the Y axis')
plt.subplots_adjust(bottom=0.13)
plt.show()