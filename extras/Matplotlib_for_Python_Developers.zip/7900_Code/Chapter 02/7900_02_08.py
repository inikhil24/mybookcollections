#!/usr/bin/python

import matplotlib.pyplot as plt
plt.plot([1, 3, 2, 4])
plt.title('Simple plot')
plt.show()