#!/usr/bin/python

import matplotlib.pyplot as plt
plt.bar([1,2,3], [3,2,5])
plt.show()