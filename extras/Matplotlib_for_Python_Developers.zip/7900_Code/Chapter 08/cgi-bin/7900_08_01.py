#!/usr/bin/python

print "Content-Type: text/html"     # headers; HTML is following
print                               # blank line, end of headers

print """<html>
<head><title>Simple CGI script</title></head>
<body><h2>Hello, world!</h2></body>
</html>"""
