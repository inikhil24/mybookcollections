
if __name__ == '__channelexec__':
	for (i, arg) in channel:
		channel.send((i, arg * 2))