=== April's Call Posts ===
Contributors: springthistle
Tags: posts, shortcode
Requires at least: 2.9.1
Tested up to: 3.0
Stable tag: 1.4

Via shortcode, lets you call in a list of posts that are filtered, displayed and ordered based on criteria you provide.

== Description ==

This plugin is useful if you are using lots of posts in a variety of ways on your website, i.e. not just on your homepage and not just separated out by categories. For example, You may have a blog with lots of information on upcoming events for your organization, and lots of announcemenets. You have a variety of people who come to your blog looking for different information, and it's hard for them to filter through everything. You can have a "Young People" page on which you talk about your organization's goals for serving young people, and use <code>[ahs_callposts]</code> to also call in a list of posts in the "young people" category, perhaps only the most recent 10, perhaps just titles, perhaps in two-column format.

== Features ==

* Specify category
* Specify number of posts
* Specify content style
* Specify multiple columns
* ... and more
* Choose global default settings that can be overridden for any individual instance of the shortcode.

== Installation ==

1. Upload 'plugin-name.php' to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Study the documentation so you understand the options
1. Start using the shortcode

== Frequently Asked Questions ==

= No questions yet =

No answers yet.

== Screenshots ==


== Changelog ==

= 1.4 =
* Added shortcode examples to settings page.
* Added col_item_width, so let you control the width of columns when in two-column mode
* Moved included styles from stylesheet to settings page, to make them easier to maintain

= 1.3 =
* Now can specify whether or not to show the date and if so, what PHP date() format to use.

= 1.2 =
* Now can specify multiple categories.

= 1.1 =
* Fixed path to icon_edit.gif.
* Added do_action so that shortcode can be used in widgets

= 1.0 =
* No significant changes have been made to the functionality; it's just being converted to a legit plugin.

= 0.5 =
* The first version of this plugin was actually a collection of functions in a single website's functions.php file.
