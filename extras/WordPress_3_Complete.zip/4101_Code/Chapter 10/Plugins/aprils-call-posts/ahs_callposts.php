<?php
/*
Plugin Name: April's Call Posts
Plugin URI: http://springthistle.com/wordpress/plugin_callposts
Description: Via shortcode, lets you call in a list of posts that are filtered, displayed and ordered based on criteria you provide. <a href="options-general.php?page=ahs_callposts.php">Edit Settings</a>.
Version: 1.4
Author: April Hodge Silver
Author URI: http://springthistle.com/
License: GPL2

    Copyright 2010  April Hodge Silver  (email : april@springthistle.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/

/*
 * ahscp_callposts_handler()
 * gets the post_content & title of the most recent published post in given category
 * to be used via shortcode only [ahscp_callposts]
 * @param string shortcode attributes
 * @returns string with post title and content
 */
function ahscp_callposts_handler($atts) {
	$out = '';
	global $post;
	extract(shortcode_atts(array(
		'type' => null,
		'category' => null,
		'custom_field'=>null,
		'title'=>null,
		'numberposts'=>1,
		'class'=>'post',
		'sidebox'=>null,
		'sideboxsize'=>'small',
		'content_style'=>null,
		'separator'=>', ',
		'cols'=>1,
		'col_item_height'=>260,
		'col_item_width'=>320,
		'showthumb'=>false,
		'order'=>'ASC',
		'dateformat'=>null,
	), $atts));

	$catids = ahscp_get_cats_array();
	
	if (empty($type)) $type = $category; // for backwards compatibility

	if ($type == null) {
		$out = ahscp_get_needs_cat_alert($catids);
	} else {
		// order by default or by custom field?
		// let shortcode override options default
		if (empty($custom_field)) $custom_field = get_option('ahscp_customfield');
		if (empty($title)) $title = get_option('ahscp_titletype');
		if (empty($title)) $title = 'h3';
		if (empty($content_style)) $content_style = get_option('ahscp_contentstyle');
		if ($dateformat != '-' ) $dateformat = get_option('ahscp_dateformat'); 
		else $dateformat = null;
		
		// if $category/$type has commas, turn it into a list of IDs
		if (ereg(',',$type)) {
			$cnames = split(",[ ]*",$type);
			$category_ids = "";
			foreach ($cnames as $n) $category_ids .= $catids[$n].',';
		} else {
			$category_ids = $catids[$type];
		}

		// get two lists of posts. the first ordered by the custom field, the second those without the custom field
		if (!empty($custom_field)) $posts1 = get_posts('numberposts='.$numberposts.'&category='.$category_ids.'&meta_key=event_date&orderby=meta_value&order='.$order);
		$posts2 = get_posts('numberposts='.$numberposts.'&category='.$category_ids);
		if (!empty($custom_field)) {
			list($out1,$used_ids) = ahscp_spit_posts($posts1,$title,$dateformat,$class,$content_style,$separator,$showthumb,$col_item_height);
			list($out2,$discard) = ahscp_spit_posts($posts2,$title,$dateformat,$class,$content_style,$separator,$showthumb,$col_item_height,$used_ids);
			$out = $out1.$out2;
		} else {
			list($out,$discard) = ahscp_spit_posts($posts2,$title,$dateformat,$class,$content_style,$separator,$showthumb,$col_item_height);
		}
	}

	if ($sidebox!=null) {
		$sizes = array('small'=>'210','medium'=>'300','large'=>'350','xlarge'=>'425');
		$out = '<div class="callposts whitespace" style="width: '.$sizes[$sideboxsize].'px;"><div class="floatbox">'.$out.'</div></div>';
	}
	
	if ($cols > 1) {
		$style = '<style>.callposts_2col .post { height: '.$col_item_height.'px; width: '.$col_item_width.'px; } ';
		if ($showthumb==true) $style .= '.wp-caption-text { display: none; }';
		$style .= '</style>';
		$out = $style.'<div class="callposts_2col">'.$out.'<div class="clr">&nbsp;</div></div>';
	}
	
	return $out;
}
/*
 * creates a string with post title and content, in a div
 * used by ahscp_callposts_handler
 * @param array of wordpress posts
 * @param HTML object to use for the title
 * @param name of class to apply to div
 * @param optional array of post IDs to exclude
 * @returns string with post title and content for all posts in the array
 */
function ahscp_spit_posts($posts,$title,$dateformat,$class,$content_style,$separator,$showthumb,$col_item_height,$exclude=array()) {
	$used_ids = array();
	$out = '';
	global $more;
	foreach($posts as $post) :
		setup_postdata($post);
		$more = 0;
		if (!in_array($post->ID,$exclude)) {
			if ($content_style != 'title') {
				$content = get_the_content('Read more &raquo;');
				$content = apply_filters('the_content', $content);
				$content = str_replace(']]>', ']]&gt;', $content);
				$content = ereg_replace('<a href="[^"]+" class="more\-link">Read more &raquo;<\/a>','<a href="'.get_permalink($post->ID).'" class="more-link">Read more &raquo;</a>',$content);
				
				$out .= '<div class="'.$class.'">';
				$out .= '<'.$title.'>';
				if (!empty($dateformat)) $out .= get_the_time($dateformat,$post->ID).' - ';
				$out .= $post->post_title;
				if ($url = get_edit_post_link($post->ID)) $out .= ' <a href="'.$url.'"><img src="/wp-content/plugins/aprils-call-posts/icon-edit.gif" width="14" alt="Edit" title="Edit this post"></a>';
				$out .= '</'.$title.'>';
				if ($showthumb==true) {
					$out .= get_the_post_thumbnail($post->ID, 'thumbnail');
					$content = strip_tags($content,'<b><strong><p><br><br />');
				}
				if ($content_style=='excerpt') {
					if (!empty($post->post_excerpt)) $excerpt = $post->post_excerpt;
					else $excerpt = get_the_excerpt();
					$out .= '<p>'.$excerpt.' <a href="'.get_permalink($post->ID).'">Read on &raquo;</a></p>';
				} else $out .= $content;
				$out .= '</div>';
			} else {
				$out .= '<a href="'.get_permalink($post->ID).'">'.$post->post_title.'</a>'.$separator;
			}
			$used_ids[]=$post->ID;
		}
	endforeach;
	$toreturn = array($out,$used_ids);
	return $toreturn;
}

add_shortcode('ahs_callposts', 'ahscp_callposts_handler');


/*
 * ahscp_get_cats_array()
 * gets an array of categories ID=>NAME
 * @returns the array of categories
 */
function ahscp_get_cats_array() {
	global $wpdb;

	$sql = "SELECT tt.term_id, t.slug  FROM ".$wpdb->prefix."term_taxonomy tt, ".$wpdb->prefix."terms t WHERE tt.taxonomy LIKE 'category' AND tt.term_id=t.term_id ORDER BY t.slug";
	$result = $wpdb->get_results($sql);

	$catids=array();	
	foreach ($result as $i) {
		$catids[$i->slug]=$i->term_id;
	}
	
	return $catids;
}

/*
 * ahscp_get_needs_cat_alert()
 * returns a string with a list of category slugs
 * @param array of catids ID=>Name
 * @returns the array of categories
 */
function ahscp_get_needs_cat_alert($catids) {
	$out = '';
	$out .= '<div style="font-style: italic; color: #666">This shortcode requires a category name. Your choices are:';
	$out .= '<ul style="margin-top: 2px;">';
	foreach (array_keys($catids) as $cat) $out .= '<li>'.$cat.'</li>';
	$out .= '</ul>For example: <code>[ahs_callposts category="'.$cat.'"]</code></div>';
	return $out;
}


/* set up options page */
function ahscp_options() {
	add_submenu_page('options-general.php', 'April\'s Call Posts', 'April\'s Call Posts', 8, basename(__FILE__), 'ahscp_options_page');
}

/**
* Build up all the params for the button
*/

function ahscp_options_page() {
?>
	<style type="text/css">.form-table { width: 700px; border-top: 1px solid #ddd; } .form-table th { width: 100px } .form-table td { padding-top: 5px; margin-bottom: 5px; } .form-table tr { border-bottom: 1px solid #ddd; }</style>
    <div class="wrap">
    <div class="icon32" id="icon-options-general"><br/></div><h2>Settings for April's Call Posts</h2>
    <p>You can choose the default settings for the shortcode here. These settings apply to every instance of the shortcode on the site, old or new, <i>unless</i> the instance itself overrides this setting.</p>
    <form method="post" action="options.php">
    <?php
        // New way of setting the fields, for WP 2.7 and newer
        if(function_exists('settings_fields')){
            settings_fields('ahscp-options');
        } else {
            wp_nonce_field('update-options');
            ?>
            <input type="hidden" name="action" value="update" />
            <input type="hidden" name="page_options" value="ahscp_customfield,ahscp_titletype,ahscp_contentstyle,ahscp_dateformat,ahscp_css" />
            <?php
        }
    ?>
        <table class="form-table">
            <tr>
                <th scope="row" valign="top"><label for="ahscp_customfield">Custom Field</label></th>
                <td>
                    <input type="text" value="<?php echo htmlspecialchars(get_option('ahscp_customfield')); ?>" name="ahscp_customfield" id="ahscp_customfield" size="15" />
                    <span class="description"><br />The shortcode automatically orders posts by most-recent-first. If you'd like them to be ordered by a custom field, enter the name of the custom field here. You can override this default setting in any individual use of the shortcode by including the option <code>custom_field</code>.</span>
                </td>
            </tr>
            <tr>
                <th scope="row" valign="top"><label for="ahscp_titletype">Title Style</label></th>
                <td>
                    <input type="text" value="<?php echo htmlspecialchars(get_option('ahscp_titletype')); ?>" name="ahscp_titletype" id="ahscp_titletype" size="5" />
                    <span class="description"><br />This is the HTML tag used for post titles in the shortcode. You can override this default setting in any individual use of the shortcode by including the option <code>title</code>.</span>
                </td>
            </tr>
            <tr>
                <th scope="row" valign="top"><label for="ahscp_contentstyle">Content Style</label></th>
                <td>
                	<?php $actual = htmlspecialchars(get_option('ahscp_contentstyle')); ?>
                    <select name="ahscp_contentstyle" id="ahscp_contentstyle">
                    	<option value="full" <?php if ($actual=='full') echo ' selected="selected"'?>>Full</option>
                    	<option value="excerpt" <?php if ($actual=='excerpt') echo ' selected="selected"'?>>Excerpt</option>
                    	<option value="title" <?php if ($actual=='title') echo ' selected="selected"'?>>Title Only</option>
                    </select>
                    <span class="description"><br />This controls whether and how each post's content is displayed. You can override this default setting in any individual use of the shortcode by including the option <code>content_style</code>.</span>
                </td>
            </tr>
            <tr>
                <th scope="row" valign="top"><label for="ahscp_dateformat">Date Format</label></th>
                <td>
                    <input type="text" value="<?php echo htmlspecialchars(get_option('ahscp_dateformat')); ?>" name="ahscp_dateformat" id="ahscp_dateformat" size="5" />
                    <span class="description"><br />If you enter a date format here, it will be used to insert the post date for all posts on the site. You can override this default setting in any individual use of the shortcode by including the option <code>dateformat</code> and setting it to a different format or to <code>-</code>.<br />A nice default is <code>F j</code>. See PHP.net's <a href="http://php.net/manual/en/function.date.php" target="_blank">Date Formatting Instructions</a> for more.</span>
                </td>
            </tr>
            <tr>
                <th scope="row" valign="top"><label for="ahscp_css">Styling</label></th>
                <td>
                    <textarea name="ahscp_css" id="ahscp_css" cols="60" rows="3" style="width: 560px"><?php echo htmlspecialchars(get_option('ahscp_css')); ?></textarea>
                    <span class="description"><br />When you first install this plugin, this box will have the default css that I put in, mostly to style the 2-column and sidebox options. You can edit this css easily here.</span>
                </td>
            </tr>
        </table>
        <p class="submit">
            <input type="submit" name="Submit" value="<?php _e('Save Changes') ?>" />
        </p>
    </form>
    
    <h3>Shortcode Options</h3>
    These are the parameters you can set in the shortcode:

    <table class="form-table">
		<tr><td><code>category</code></td><td>No default. Required. Enter the slug of the category you'd like to use. Separate multiple category slugs with commas.</td></tr>
		<tr><td><code>custom_field</code></td><td>Default is the option set above, if not empty. Otherwise, ignored.</td></tr>
		<tr><td><code>title</code></td><td>Default = h3. Can be any HTML tag name (b, i, u, h4, etc)</td></tr>
		<tr><td><code>dateformat</code></td><td>Default is to not show the date. If you enter a dateformat for an instance of the shortcode (or above as a default for the whole site), the date will be shown preceding the title (if <code>content_type</code> is not <code>title</code>). <a href="http://php.net/manual/en/function.date.php" target="_blank">Formatting tips</a>.</td></tr>
		<tr><td><code>numberposts</code></td><td>Default = 1. This is the number of posts that are called in. To have no limit, use <code>-1</code>.</td></tr>
		<tr><td><code>class</code></td><td>Default = post. You can choose another class, for example, one controlled in your own theme's stylesheet, instead.</td></tr>
		<tr><td><code>sidebox</code></td><td>Empty and ignored by default. If set to <code>true</code>, puts the posts in a box floating at the right side of the page.</td></tr>
		<tr><td><code>sideboxsize</code></td><td>Empty and ignored by default. Only used if sidebox is set to true. Then, default = "small" which translates to a width of 210px. Other options are: <code>medium</code> (300px), <code>large</code> (350px), <code>xlarge</code> (425px). Height of the sidebox is determined by the length of the content.</td></tr>
		<tr><td><code>content_style</code></td><td>Default = option set above. To override the default, set to one of these other options in the shortcode: <code>excerpt</code>, <code>title</code>.</td></tr>
		<tr><td><code>separator</code></td><td>Default is a comma (,). Only used if content_style is set to title.</td></tr>
		<tr><td><code>cols</code></td><td>Default = 1. Only other option is <code>2</code>.</td></tr>
		<tr><td><code>col_item_width</code></td><td>Empty and ignored by default. Only used if cols is set to <code>2</code>. Then the default = 320, which is a pixel measurement.</td></tr>
		<tr><td><code>col_item_height</code></td><td>Empty and ignored by default. Only used if cols is set to <code>2</code>. Then the default = 260, which is a pixel measurement.</td></tr>
		<tr><td><code>showthumb</code></td><td>Empty and ignored by default. If set to true, then the post thumbnail is displayed before the post (You choose the post thumbnail at the bottom right on the Edit Post page). The image has the class <code>attachment-thumbnail</code>, so you can style it.</td></tr>
		<tr><td><code>order</code></td><td>Default is ASC. Can be set to <code>DESC</code>. Used only when a custom field is set.</td></tr>
    </table>
    
    <p>&nbsp;</p>

    <h3>Shortcode Examples</h3>
    
	<?php 	
	global $wpdb;

	$sql = "SELECT t.slug  FROM ".$wpdb->prefix."term_taxonomy tt, ".$wpdb->prefix."terms t WHERE tt.taxonomy LIKE 'category' AND tt.term_id=t.term_id AND tt.term_id=1 ORDER BY t.slug";
	$result = $wpdb->get_results($sql);
	foreach ($result as $i) $slugexample = $i->slug;
	?>
    
    <p>If you want to call the 5 most recent posts in the <b><?php echo ucfirst($slugexample) ?></b> category into a page, place this shortcode on the page:</p>
    <p><code>[ahs_callposts category="<?php echo $slugexample ?>" numberposts="5"]</code></p>
    
    <p>&nbsp;</p>

    <p>If you want to call all posts in the <b><?php echo ucfirst($slugexample) ?></b> category into a page but only list linkable titles with hard returns between them, place this shortcode on the page:</p>
    <p><code>[ahs_callposts category="<?php echo $slugexample ?>" numberposts="-1" content_style="title" separator="&lt;br /&gt;"]</code></p>
    
    <p>&nbsp;</p>

    <p>If you want to call the 6 most recent posts in the <b><?php echo ucfirst($slugexample) ?></b> category into a page in two columns 220px wide with a thumbnail image:</p>
    <p><code>[ahs_callposts category="<?php echo $slugexample ?>" numberposts="6" cols="2" showthumb="true" col_item_width="220"]</code></p>
    
    <p>&nbsp;</p>
    </div>
<?php
}

// this functions adds the stylesheet to the head
function ahscp_callposts_styles() {
	echo "\n<!-- Begin css from April\'s Call Posts -->\n";
	echo '<style type="text/css">'."\n";
	echo htmlspecialchars(get_option('ahscp_css'));
	echo "\n</style>";	
	echo "\n<!-- End css from April\'s Call Posts -->\n\n";
}


// On access of the admin page, register these variables (required for WP 2.7 & newer)
function ahscp_init(){
    if(function_exists('register_setting')){
        register_setting('ahscp-options', 'ahscp_customfield');
        register_setting('ahscp-options', 'ahscp_titletype');
        register_setting('ahscp-options', 'ahscp_contentstyle');
        register_setting('ahscp-options', 'ahscp_dateformat');
        register_setting('ahscp-options', 'ahscp_css');
    }
}

// Only all the admin options if the user is an admin
if(is_admin()){
    add_action('admin_menu', 'ahscp_options');
    add_action('admin_init', 'ahscp_init');
}

// Set the default options when the plugin is activated
function ahscp_activate(){
    add_option('ahscp_customfield', '');
    add_option('ahscp_titletype', '');
    add_option('ahscp_contentstyle', 'excerpt');
    add_option('ahscp_dateformat', '');
    add_option('ahscp_css', ".callposts_2col .post { float: left; margin-right: 20px; border-bottom: 1px solid #999; overflow: hidden; clear: none; }\n.callposts_2col .post h3 { margin-bottom: 0; }\n.callposts_2col .clr { height: 20px; }\n.callposts.whitespace { background: #fff; width: 225px; float: right; margin-right: -10px; padding: 0 0 10px 10px; }\n.callposts .floatbox { background-color: #eee; padding: 15px; float: right; margin: 10px -10px 10px 10px;}\n.clr { clear: both; }");
}

register_activation_hook( __FILE__, 'ahscp_activate');
add_action('wp_head', 'ahscp_callposts_styles');

// so that widget text is analyzed for shortcodes
add_filter('widget_text', 'do_shortcode');

?>