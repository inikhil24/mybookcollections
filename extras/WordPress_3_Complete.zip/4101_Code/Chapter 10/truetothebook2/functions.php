<?php

// be sure the theme supports post thumbnails and automatic theme links
add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );

// register two navigation menu locations in the theme
register_nav_menus( array(
	'main' => 'Main Navigation',
	'foot' => 'Footer Navigation',
) );

// register three sidebars (i.e. widget locations)
// one for pages, one for books, one for everything else
register_sidebar( array(
	'name' => 'Pages Widget Area',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
) );

register_sidebar( array(
	'name' => 'Blog Widget Area',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
) );

register_sidebar( array(
	'name' => 'Books Widget Area',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
) );

// set up custom post_type
add_action('init', 'book_init');
function book_init() {
	$labels = array(
		'name' => _x('Books', 'post type general name'),
		'singular_name' => _x('Book', 'post type singular name'),
		'add_new' => _x('Add New', 'book'),
		'add_new_item' => __('Add New Book'),
		'edit_item' => __('Edit Book'),
		'new_item' => __('New Book'),
		'view_item' => __('View Book'),
		'search_items' => __('Search Books'),
		'not_found' =>  __('No books found'),
		'not_found_in_trash' => __('No books found in Trash'), 
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => array('slug' => 'books', 'with_front'=>false),
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','editor','custom-fields','thumbnail'),
		'taxonomies' => array('book_category'),
	); 
	register_post_type('book',$args);
}

//add filter to insure the text Book, or book, is displayed when user updates a book 
add_filter('post_updated_messages', 'book_updated_messages');
function book_updated_messages( $messages ) {
	
	$messages['book'] = array(
		0 => '', // Unused. Messages start at index 1.
		1 => sprintf( __('Book updated. <a href="%s">View book</a>'), esc_url( get_permalink($post_ID) ) ),
		2 => __('Custom field updated.'),
		3 => __('Custom field deleted.'),
		4 => __('Book updated.'),
		/* translators: %s: date and time of the revision */
		5 => isset($_GET['revision']) ? sprintf( __('Book restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __('Book published. <a href="%s">View book</a>'), esc_url( get_permalink($post_ID) ) ),
		7 => __('Book saved.'),
		8 => sprintf( __('Book submitted. <a target="_blank" href="%s">Preview book</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		9 => sprintf( __('Book scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview book</a>'),
		  date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
		10 => sprintf( __('Book draft updated. <a target="_blank" href="%s">Preview book</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
	);
	
	return $messages;
}


// special conditional function
function is_book() {
    global $wp_query;
	if ('book' == $wp_query->query_vars['post_type']) return true;
	else return false;
}

// set up custom taxonomy
add_action( 'init', 'build_taxonomies', 0 );  
function build_taxonomies() {
	register_taxonomy(
		'book_category',
		'book',
		array(
			'hierarchical' => true,
			'label' => 'Book Category',
			'query_var' => true,
			'rewrite' => true,
		)
	);
}

// alter admin display
add_filter('posts_orderby', 'ahs_orderby');
function ahs_orderby($sql) {
    global $wpdb, $wp_query;
    if ( is_admin() && is_book() ) {
        return $wpdb->prefix . "posts.post_title ASC";
    }
    return $sql;
}

add_filter('manage_posts_columns', 'ahs_custom_columns');
function ahs_custom_columns($defaults) {
    global $wp_query;
	if (is_book()) {
	    unset($defaults['comments']);
	    unset($defaults['author']);
	    unset($defaults['categories']);
	    unset($defaults['date']);
    	$defaults['book_category'] = 'Categories';
    	$defaults['thumbnail'] = 'Image';
    }
    return $defaults;
}

add_action('manage_posts_custom_column',  'ahs_show_columns');
function ahs_show_columns($name) {
    global $post;
    switch ($name) {
        case 'book_category':
            echo get_the_term_list($post->ID,'book_category','',', ','');
            break;
        case 'thumbnail':
            if (has_post_thumbnail($post->ID)) echo get_the_post_thumbnail($post->ID, array('50','50'));
            break;
    }
}

?>