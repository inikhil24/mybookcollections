<?php get_header() ?>

<?php if (have_posts()) : ?>

	<?php while (have_posts()) : the_post(); ?>

		<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
			<h2><?php the_title(); ?></h2>

			<div class="entry">
				<b>By <?php echo get_post_meta($post->ID, 'book_author', true); ?></b>
				<?php if (has_post_thumbnail($post->ID)) echo get_the_post_thumbnail($post->ID, 'medium', array('class'=>"alignleft")); ?>
				<?php the_content(); ?>
			</div>
			
			<div class="clr">&nbsp;</div>
			
			<?php echo get_the_term_list($post->ID,'book_category','<b>Categories:</b> ',', ','') ?>
			
		</div>

	<?php endwhile; endif; ?>

<?php get_footer() ?>