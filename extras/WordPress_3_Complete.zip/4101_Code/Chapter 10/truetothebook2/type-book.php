<?php get_header() ?>

<h2>Books</h2>

<?php if (have_posts()) : ?>

	<?php while (have_posts()) : the_post(); ?>

	<div <?php post_class() ?> id="post-<?php the_ID(); ?>">	
		
		<?php if (has_post_thumbnail($post->ID)) echo '<a href="'.get_permalink().'">'.get_the_post_thumbnail($post->ID, 'thumbnail', array('class'=>"alignleft")).'</a>'; ?>
		
		<h3><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h3>
		<small>By <?php echo get_post_meta($post->ID, 'book_author', true); ?></small>
		
		<?php echo the_excerpt(); ?>
		<div class="clr">&nbsp;</div>
	</div>
	
	<?php endwhile; ?>

	<div class="navigation">
		<div class="alignleft"><?php next_posts_link('&laquo; Next Page') ?></div>
		<div class="alignright"><?php previous_posts_link('Previous Page &raquo;') ?></div>
	</div>

<?php else : ?>

	<h2 class="center">Not Found</h2>
	<p class="center">Sorry, but you are looking for something that isn't here.</p>
	<?php get_search_form(); ?>

<?php endif; ?>

<?php get_footer() ?>