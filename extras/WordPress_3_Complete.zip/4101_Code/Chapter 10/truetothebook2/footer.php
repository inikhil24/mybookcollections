		</div>
		<div id="sidebar">
			<?php 
			if (is_book() || 'book_category' == $wp_query->query_vars['taxonomy']) dynamic_sidebar('Books Widget Area');
			else 
			if (is_page() || is_search()) dynamic_sidebar('Pages Widget Area');
			else dynamic_sidebar('Blog Widget Area');
			?>
		</div>
		<div class="clr">&nbsp;</div>
	</div>
	<div id="midbot">&nbsp;</div>
</div>

<div id="footer">
	<?php wp_nav_menu('theme_location=foot&depth=1') ?>
	All content copyright &copy; <?php echo date('Y'); ?> by <?php bloginfo('name'); ?>
</div>

<?php wp_footer(); ?>
</body>
</html>