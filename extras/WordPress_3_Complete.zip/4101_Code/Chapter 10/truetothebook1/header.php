<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<title><?php
	wp_title( '|', true, 'right' );
	bloginfo( 'name' ); ?>
</title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div id="header">
	<h1><?php bloginfo('name'); ?></h1>
	<div class="description"><?php bloginfo('description') ?></div>
	<a href="<?php bloginfo('home') ?>" id="homelink">Back to home</a>
	<?php wp_nav_menu('theme_location=main&depth=2') ?>
</div>

<div id="middle">
	<div id="midtop">&nbsp;</div>
	<div id="container">
		<div id="content">