<?php get_header() ?>

<?php if ( $wp_query->max_num_pages > 1 ) : ?>
	<div id="nav-above" class="navigation">
		<div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', 'twentyten' ) ); ?></div>
		<div class="nav-next"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', 'twentyten' ) ); ?></div>
	</div><!-- #nav-above -->
<?php endif; ?>

<?php /* If there are no posts to display, such as an empty archive page */ ?>
<?php if ( ! have_posts() ) : ?>
	<div id="post-0" class="post error404 not-found">
		<h2>Not Found</h2>
			<p>Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.</p>
			<?php get_search_form(); ?>
	</div><!-- #post-0 -->
<?php endif; ?>

<?php if (is_search() ) echo 'Search results for <i>'.$s.'</i>'; ?>

<?php while ( have_posts() ) : the_post(); ?>

		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<h2><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>

			<div class="postmeta"><?php the_time('F j, Y'); ?> <?php edit_post_link('Edit', ' | ', '' ); ?></div><!-- .entry-meta -->

			<?php 
				if ( is_archive() || is_search() ) {
				
				if (has_post_thumbnail($post->ID)) 
					echo '<a href="'.get_permalink().'" rel="bookmark">'.get_the_post_thumbnail($post->ID, array(75,75), array('class'=>"alignleft")).'</a>';
					the_excerpt(); 
				
				} else the_content('Continue reading &rarr;'); 
			?>
		</div>

<?php endwhile; ?>

<?php get_footer() ?>
