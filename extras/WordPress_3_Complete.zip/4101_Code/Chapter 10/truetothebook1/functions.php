<?php

// be sure the theme supports post thumbnails and automatic theme links
add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );

// register two navigation menu locations in the theme
register_nav_menus( array(
	'main' => 'Main Navigation',
	'foot' => 'Footer Navigation',
) );

// register two sidebars (i.e. widget locations)
// one for pages, one for books, one for everything else
register_sidebar( array(
	'name' => 'Pages Widget Area',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
) );

register_sidebar( array(
	'name' => 'Blog Widget Area',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
) );

register_sidebar( array(
	'name' => 'Books Widget Area',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
) );

?>