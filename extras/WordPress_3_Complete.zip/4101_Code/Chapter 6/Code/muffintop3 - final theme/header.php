<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<title><?php bloginfo('name'); ?></title>
	<meta name="robots" content="index, follow"></meta>
	<meta name="distribution" content="global"></meta>
	<meta name="description" content="discovering new recipes and food daily"></meta>
	<meta name="keywords" content="april hodge silver, food, recipes"></meta>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head(); ?>
</head>

<body <?php body_class() ?>>

<a name="top"></a>

<div id="container">

	<div id="header">
		<div id="mainnav">
			<?php 
				if (function_exists('wp_nav_menu')) wp_nav_menu('depth=2'); 
				else {
					echo '<ul>';
					wp_list_pages('title_li=&sort_column=menu_order&depth=2');
					echo '</ul>';
				}
			?>
		</div><!-- /mainnav -->
		
		<h1><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
		<div id="description"><?php bloginfo('description'); ?></div>
	</div><!-- /header -->

	<div id="content">
