<?php
if ( function_exists('register_sidebar') )
    register_sidebar();

function recent_post_func($atts) {
	extract(shortcode_atts(array(
		'authorid' => null,
		'numberposts' => 1,
	), $atts));

	$args = 'numberposts='.$numberposts;
	if ($authorid) $args .= '&author='.$authorid;

	$posts = get_posts($args);
	$out = '';
	foreach ($posts as $post) {
		setup_postdata($post);
		$out .= '<div class="ahs_recentpost"';
		$out .= '<h4><a href="'.get_permalink($post->ID).'">'.get_the_title($post->ID).'</a></h4>';
		$out .= apply_filters('the_content', get_the_content());
		$out .= '</div>';
	}
	return $out;
}

add_shortcode('ahs_recentpost', 'recent_post_func');

add_filter('widget_text', 'do_shortcode');

register_nav_menus( array(
	'primary' =>'Main Navigation',
	'footer' => 'Footer Menu',
) );

?>