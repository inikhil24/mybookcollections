<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<title><?php bloginfo('name'); ?></title>
	<meta name="robots" content="index, follow"></meta>
	<meta name="distribution" content="global"></meta>
	<meta name="description" content="discovering new recipes and food daily"></meta>
	<meta name="keywords" content="april hodge silver, food, recipes"></meta>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head(); ?>
</head>

<body <?php body_class() ?>>

<a name="top"></a>

<div id="container">

	<div id="header">
		<div id="mainnav">
			<?php 
				if (function_exists('wp_nav_menu')) wp_nav_menu('depth=2'); 
				else {
					echo '<ul>';
					wp_list_pages('title_li=&sort_column=menu_order&depth=2');
					echo '</ul>';
				}
			?>
		</div><!-- /mainnav -->
		
		<h1><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
		<div id="description"><?php bloginfo('description'); ?></div>
	</div><!-- /header -->

	<div id="content">
		<div id="copy">

			<?php if (have_posts()) : ?>
			
				<?php while (have_posts()) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class() ?>>
						<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
						<div class="post-date"><?php the_time('F jS, Y') ?></div>
			
						<?php the_content(); ?>
			
						<div class="categories">Posted in: <?php the_category(', ') ?></div>
						<div class="tags">Tags: <?php the_tags(); ?></div>
						<div class="comments"><?php comments_popup_link('Leave a Comment &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></div>
					</div>
				<?php endwhile; ?>
			
				<div class="navigation">
					<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
					<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
				</div>
			<?php else : ?>
				<h2 class="center">Not Found</h2>
				<p class="center">Sorry, but you are looking for something that isn't here.</p>
				<?php get_search_form(); ?>
			<?php endif; ?>

		</div><!-- /copy -->
		
		<div id="sidebar">
			<h3 class="first">Categories</h3>
			<ul>
				<?php wp_list_categories('title_li='); ?>
			</ul>
			
			<h3>Archives</h3>
			<ul>
				<?php wp_get_archives(); ?>
			</ul>
			
			<h3>Search</h3>
			<?php get_search_form(); ?>
		</div><!-- /sidebar -->
		
		<div style="clear: both">&nbsp;</div>
	</div><!-- /content -->
	
	<div id="footer">
		<a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> is powered by wordpress
	</div><!-- /footer -->

</div><!-- /container -->

<?php wp_footer() ?>
</body>
</html>