<?php
/*
Plugin Name: April's List Posts Cat Widget
Plugin URI: http://springthistle.com/wordpress/plugin_postfromcat
Description: Allows you to add a widget with some number of most recent posts from a particular category
Author: April Hodge Silver
Version: 1.0
Author URI: http://springthistle.com
*/

class Posts_From_Category extends WP_Widget {

	function Posts_From_Category() {
		/* Widget settings. */
		$widget_ops = array(
			'classname' => 'postsfromcat', 
			'description' => 'Allows you to display a list of recent posts within a particular category.');

		/* Widget control settings. */
		$control_ops = array(
			'width' => 250, 
			'height' => 250, 
			'id_base' => 'postsfromcat-widget');

		/* Create the widget. */
		$this->WP_Widget('postsfromcat-widget', 'Posts from a Category', $widget_ops, $control_ops );
	}
	
	function form ($instance) {

		/* Set up some default widget settings. */
		$defaults = array('numberposts' => '5');
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
			<input type="text" name="<?php echo $this->get_field_name('title') ?>" id="<?php echo $this->get_field_id('title') ?> " value="<?php echo $instance['title'] ?>" size="20">
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('catid'); ?>">Category:</label>
			<?php wp_dropdown_categories('hide_empty=0&hierarchical=1&id='.$this->get_field_id('catid').'&name='.$this->get_field_name('catid').'&selected='.$instance['catid']); ?>
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('numberposts'); ?>">Number of posts:</label>
			<select id="<?php echo $this->get_field_id('numberposts'); ?>" name="<?php echo $this->get_field_name('numberposts'); ?>">
			<?php for ($i=1;$i<=20;$i++) {
				echo '<option value="'.$i.'"';
				if ($i==$instance['numberposts']) echo ' selected="selected"';
				echo '>'.$i.'</option>';
			} ?>
			</select>
		</p>
		
		<p>
			<input type="checkbox" id="<?php echo $this->get_field_id('rss'); ?>" name="<?php echo $this->get_field_name('rss'); ?>" <?php if ($instance['rss']) echo 'checked="checked"' ?> />
			<label for="<?php echo $this->get_field_id('rss'); ?>">Show RSS feed link?</label>
		</p>
		
		<?php
	}

	function update ($new_instance, $old_instance) {
		$instance = $old_instance;

		$instance['catid'] = $new_instance['catid'];
		$instance['numberposts'] = $new_instance['numberposts'];
		$instance['title'] = $new_instance['title'];
		$instance['rss'] = $new_instance['rss'];

		return $instance;
	}

	function widget ($args,$instance) {
		extract($args);

		$title = $instance['title'];
		$catid = $instance['catid'];
		$numberposts = $instance['numberposts'];
		$rss = $instance['rss'];
	
		// retrieve posts information from database
		global $wpdb;
		$posts = get_posts('numberposts='.$numberposts.'&category='.$catid);
		$out = '<ul>';
		foreach($posts as $post) {
			$out .= '<li><a href="'.get_permalink($post->ID).'">'.$post->post_title.'</a></li>';
		}
		if ($rss) $out .= '<li><a href="'.get_category_link($catid).'feed/" class="rss">Category RSS</a></li>';
		$out .= '</ul>';
				
		//print the widget for the sidebar
		echo $before_widget;
		echo $before_title.$title.$after_title;
		echo $out;
		echo $after_widget;
	}

}

function ahspfc_load_widgets() {
	register_widget('Posts_From_Category');
}

add_action('widgets_init', 'ahspfc_load_widgets');

?>