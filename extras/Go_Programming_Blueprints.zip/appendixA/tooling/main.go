package main

import "fmt"

func main() {
	return

	var name string
	name = "Mat"
	fmt.Println("Hello ", name)

}
